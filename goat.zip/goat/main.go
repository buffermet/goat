package main

import (
  "net"
  "os"
  "regexp"
  "strconv"

  "github.com/notbuffermet/goat/lib/session"
  "github.com/notbuffermet/goat/lib/ui"
)

var (
  ip   = "0.0.0.0"
  port = "9636"
  whitelist = []string{
    "127.0.0.1",
  }
)

func parseFlags() {
  for i := 1; i < len(os.Args); i++ {
    if 0 != len(regexp.MustCompile(`^[-]+ip$`).FindString(os.Args[i])) {
      // -ip
      ip_string := os.Args[i + 1]
      if net.ParseIP(ip_string) == nil {
        println("error: invalid IP provided (got " + ip_string + ")")
        os.Exit(1)
      }
      ip = ip_string
    } else if 0 != len(regexp.MustCompile(`^[-]+port$`).FindString(os.Args[i])) {
      // -port
      port_string := os.Args[i + 1]
      p, err := strconv.Atoi(port_string)
      if err != nil || p < 1 || p > 65535 {
        println("error: invalid port provided (got " + port_string + ")")
        os.Exit(1)
      }
      port = port_string
    } else if 0 != len(regexp.MustCompile(`^[-]+whitelist$`).FindString(os.Args[i])) {
      // -whitelist
      whitelist_string := os.Args[i + 1]
      ips := regexp.MustCompile(",").Split(whitelist_string, -1)
      for _, _ip := range ips {
        if net.ParseIP(_ip) == nil {
          println("error: invalid ip provided to whitelist (got " + _ip + ")")
          os.Exit(1)
        }
      }
      whitelist = ips
    }
  }
}

func main() {
  parseFlags()
  s := session.GoatSession{
    ip,
    port,
    &whitelist,
  }
  ui.Start(&s)
}
