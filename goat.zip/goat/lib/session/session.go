package session

import "sync"

type GoatSession struct {
  IP string
  Port string
  Waitgroup *sync.WaitGroup
  Whitelist *[]string
}
