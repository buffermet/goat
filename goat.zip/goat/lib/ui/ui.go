package ui

import (
  "net/http"
  "os"
  "os/exec"
  "reflect"
  "runtime"
  "time"

  "github.com/notbuffermet/goat/lib/session"
)

func openBrowser(url string) {
  var command string
  if runtime.GOOS == "android" {
    command = "am start -a com.chrome.canary/com.google.android.apps.chrome.Main -d " + url
//  } else if os.LINUX {
//    command = "chromium --incognito --app=" + url
//  } else if os.MAC {
//    command = ""
//  } else if os.WINDOWS {
  } else {
    command = "chromium --incognito --app=" + url
  }
  proc := exec.Command(command)
  stdoutPipe, err := proc.StdoutPipe()
  stderrPipe, err := proc.StderrPipe()
  fooType := reflect.TypeOf(stdoutPipe)
  for i := 0; i < fooType.NumMethod(); i++ {
      method := fooType.Method(i)
      println(method.Name)
  }
}

func Stop(s *session.GoatSession) {
  s.Waitgroup.Done()
}

func Start(s *session.GoatSession) {
  s.Waitgroup.Add(1)

  handler := http.HandleFunc(
    "/",
    func(w http.ResponseWriter, req *http.Request) {
    fooType := reflect.TypeOf(req)
      for i := 0; i < fooType.NumMethod(); i++ {
          method := fooType.Method(i)
          println(method.Name)
      }
    },
  )

  server := &http.Server{
    Addr:           s.IP + ":" + s.Port,
    Handler:        handler,
    ReadTimeout:    10 * time.Second,
    WriteTimeout:   10 * time.Second,
    MaxHeaderBytes: 1 << 20,
  }

  go func(){
    println(server.ListenAndServe())
    os.Exit(1)
  }()

  s.Waitgroup.Wait()
}
